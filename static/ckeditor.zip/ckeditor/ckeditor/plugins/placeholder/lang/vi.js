﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","vi",{title:"Thuộc tính đặt chỗ",toolbar:"Tạo đặt chỗ",name:"Tên giữ chỗ",invalidName:"Giữ chỗ không thể để trống và không thể chứa bất kỳ ký tự sau: [,], <, >",pathName:"giữ chỗ"});